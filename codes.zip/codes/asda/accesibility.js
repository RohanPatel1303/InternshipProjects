import React from "react";
import { Acces View } from "react-native";
const accesibility=()=>{
    render()
    return{
        <View accessible={true}
        accessibilityLabel="Tap me!">

    }
}
export default accesibility;