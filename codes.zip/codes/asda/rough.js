<TextInput focusable nextFocusForward={"2"} nativeID="1" placeholder="TEXT HERE"
></TextInput>
<TextInput nativeID="2" focusable={true}placeholder="hello text here"></TextInput>
<Button nextFocusDown={1} title="hello"></Button>