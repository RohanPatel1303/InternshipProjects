import React from "react";
import { Component } from "react";
import { Text,View, } from "react-native";
const Hello=()=>{
    return(
        <View >
            <Text>Hello World This Is Hello World Component</Text>
            <View>
                
            </View>
        </View>
    
    )

}
export default Hello;