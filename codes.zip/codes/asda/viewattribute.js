import React from "react";
import { View,Text } from "react-native";
Viewattributes=() => {
return(

    <View style={{ borderWidth: 2, borderColor: 'red' }}>
        <Text> The Box Is Having A Border Of 2dpi And Color Red.
        </Text>
    </View>
)


    
}
export default Viewattributes